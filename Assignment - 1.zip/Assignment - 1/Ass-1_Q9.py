def Even():
    for i in range(0,20,2):
        print(i)
def main():
    Even()


if __name__ =="__main__":
    main()
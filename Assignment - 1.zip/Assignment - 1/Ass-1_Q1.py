def Fun():
    print("Hello")
Fun()



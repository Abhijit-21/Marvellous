
def main():
    print("Enter the Text : ")
    no1 = input()
    print("Length of string is : ", len(no1))


if __name__ =="__main__":
    main()
def iteration():
    num = 0
    while(num<=5):
        print("Marvellous")
        num = num + 1

def main():
    iteration()

if __name__ =="__main__":
    main()

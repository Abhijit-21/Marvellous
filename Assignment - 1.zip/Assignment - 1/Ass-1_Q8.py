def Pattern(val1):
    for i in range(0,val1):
        print("*")


def main():
    print("Enter the number : ")
    no1 = int(input())
    Pattern(no1)


if __name__ =="__main__":
    main()